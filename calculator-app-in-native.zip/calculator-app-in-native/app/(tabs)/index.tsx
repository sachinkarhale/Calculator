import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, SafeAreaView } from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';

interface ButtonProps {
  children: React.ReactNode;
  onClick: () => void;
  className?: string;
}

const Calculator: React.FC = () => {
  const [display, setDisplay] = useState<string>('0');
  const [equation, setEquation] = useState<string>('');
  const [isNewNumber, setIsNewNumber] = useState<boolean>(true);
  const [isDarkMode, setIsDarkMode] = useState<boolean>(true);

  const handleNumber = (num: string): void => {
    if (isNewNumber) {
      setDisplay(num);
      setIsNewNumber(false);
    } else {
      setDisplay(display + num);
    }
  };

  const handleOperator = (operator: string): void => {
    setEquation(display + ' ' + operator + ' ');
    setIsNewNumber(true);
  };

  const handleEqual = (): void => {
    try {
      const result = Function(`return ${equation + display}`)();
      setDisplay(String(result));
      setEquation('');
      setIsNewNumber(true);
    } catch {
      setDisplay('Error');
      setEquation('');
      setIsNewNumber(true);
    }
  };

  const handleClear = (): void => {
    setDisplay('0');
    setEquation('');
    setIsNewNumber(true);
  };

  const Button: React.FC<ButtonProps> = ({ children, onClick, className }) => (
    <TouchableOpacity onPress={onClick} style={[styles.button, className]}>
      <Text style={styles.buttonText}>{children}</Text>
    </TouchableOpacity>
  );

  const themeClass = isDarkMode
    ? styles.darkMode
    : styles.lightMode;

  return (
    <SafeAreaView style={[styles.container, themeClass]}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => setIsDarkMode(!isDarkMode)} style={styles.iconButton}>
          {isDarkMode ? (
            <Icon name="sunny" size={30} color="#FFD700" />
          ) : (
            <Icon name="moon" size={30} color="#333" />
          )}
        </TouchableOpacity>
      </View>

      <View style={styles.display}>
        <Text style={styles.equationText}>{equation}</Text>
        <Text style={styles.displayText}>{display}</Text>
      </View>

      <View style={styles.buttons}>
        {/* First row */}
        <View style={styles.buttonRow}>
          <Button onClick={handleClear} className={styles.clearButton}>AC</Button>
          <Button onClick={() => handleOperator('/')} className={styles.operatorButton}>/</Button>
          <Button onClick={() => handleOperator('*')} className={styles.operatorButton}>x</Button>
          <Button onClick={() => handleOperator('-')} className={styles.operatorButton}>-</Button>
        </View>

        {/* Second row */}
        <View style={styles.buttonRow}>
          <Button onClick={() => handleNumber('7')} className={styles.numberButton}>7</Button>
          <Button onClick={() => handleNumber('8')} className={styles.numberButton}>8</Button>
          <Button onClick={() => handleNumber('9')} className={styles.numberButton}>9</Button>
          <Button onClick={() => handleOperator('+')} className={styles.operatorButton}>+</Button>
        </View>

        {/* Third row */}
        <View style={styles.buttonRow}>
          <Button onClick={() => handleNumber('4')} className={styles.numberButton}>4</Button>
          <Button onClick={() => handleNumber('5')} className={styles.numberButton}>5</Button>
          <Button onClick={() => handleNumber('6')} className={styles.numberButton}>6</Button>
          <Button onClick={handleEqual} className={styles.equalButton1}>=</Button>
        </View>

        {/* Fourth row */}
        <View style={styles.buttonRow}>
          <Button onClick={() => handleNumber('1')} className={styles.numberButton}>1</Button>
          <Button onClick={() => handleNumber('2')} className={styles.numberButton}>2</Button>
          <Button onClick={() => handleNumber('3')} className={styles.numberButton}>3</Button>
          <Button onClick={handleEqual} className={styles.equalButton2}>=</Button>
        </View>

        {/* Fifth row */}
        <View style={styles.buttonRow}>
          <Button onClick={() => handleNumber('0')} className={[styles.numberButton, styles.zeroButton]}>0</Button>
          <Button onClick={() => handleNumber('.')} className={styles.numberButton}>.</Button>
          <Button onClick={() => setIsDarkMode(!isDarkMode)} className={styles.themeButton}>Dark/Light</Button>
        </View>
      </View>

      <Text style={styles.footer}>Calc by Atharva</Text>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: 20,
  },
  darkMode: {
    backgroundColor: '#1c1c1c',
    color: 'white',
  },
  lightMode: {
    backgroundColor: '#f9f9f9',
    color: '#333',
  },
  header: {
    alignSelf: 'flex-end',
    marginRight: 20,
  },
  iconButton: {
    padding: 10,
  },
  display: {
    width: '90%',
    marginBottom: 30,
    backgroundColor: '#2f2f2f',
    padding: 20,
    borderRadius: 15,
    alignItems: 'flex-end',
    marginTop: 10,
  },
  equationText: {
    fontSize: 22,
    color: '#b0b0b0',
  },
  displayText: {
    fontSize: 60,
    fontWeight: 'bold',
    color: '#fff',
  },
  buttons: {
    width: '90%',
  },
  buttonRow: {
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 10,
  },
  button: {
    width: '22%',
    padding: 20,
    margin: 5,
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#4caf50', // Green background for all buttons
  },
  buttonText: {
    fontSize: 28,
    fontWeight: '600',
    color: '#fff',
  },
  clearButton: {
    backgroundColor: '#ff4d4d', // Red for AC button
  },
  operatorButton: {
    backgroundColor: '#ff8c00', // Orange for operator buttons
  },
  numberButton: {
    backgroundColor: '#444', // Dark grey for number buttons
  },
  equalButton: {
    height:'0px',
    backgroundColor: '#4caf50', // Green for the equal button
  },
  
  zeroButton: {
    width: '48%', // Makes the 0 button largerp
    marginRight:'20px',
  },
  themeButton: {
    backgroundColor: '#555', // Dark button for theme toggle
  },
  footer: {
    fontSize: 12,
    color: '#b0b0b0',
    marginTop: 20,
  },
});

export default Calculator;
